/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package play3;
  
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.application.Application;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import javafx.event.EventType;
import javafx.scene.control.Button;
import java.util.Timer;
import java.util.TimerTask;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.transform.Rotate;
/**
 *
 * @author extra
 */

public class Level3Controller implements Initializable {


    @FXML
   private TextField v;
   private Label lb;
   private Button b;
   private Pane root;
   @FXML
    private ImageView Imag5;
   @FXML
   private ImageView next;
   
      
   private Media AudioHint3 = new Media("https://e.top4top.io/m_2705bbml11.mp3");
    MediaPlayer Hint3=new MediaPlayer(AudioHint3);

   
    public void Hint(ActionEvent event) {
Hint3.play();
    }         
        private Media AudioNoo3 = new Media("https://e.top4top.io/m_27051a7781.mp3");
    MediaPlayer Noo3=new MediaPlayer(AudioNoo3);      
        
        
    private Media AudioWow3 = new Media("https://c.top4top.io/m_2705j34ng1.mp3");
    MediaPlayer Wow3=new MediaPlayer(AudioWow3);
    

        
    
    public void OK(ActionEvent event) throws IOException {
        Wow3.play();
       if (v.getText().equalsIgnoreCase("orange")) {
      
    
    }
       else {
               Noo3.play();
       
           
       }

    }

    public void load(MouseEvent event) throws IOException {
     Parent root = FXMLLoader.load(getClass().getResource("obList.fxml"));
     Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
      @FXML
    void backhome(MouseEvent event) throws IOException {
Parent root = FXMLLoader.load(getClass().getResource("FXML4.fxml"));
     Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
    
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    
    
}
