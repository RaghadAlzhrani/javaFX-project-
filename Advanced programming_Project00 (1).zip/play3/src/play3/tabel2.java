/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;

import javax.persistence.Entity;
import javax.persistence.*;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 *
 * @author elafh
 */
@Entity
@Table(name="tabel2")
public class tabel2 implements Serializable {
@Id
     @Column (name="name2")
    String name;
     
     
      @Id
     @Column (name="choose")
    String choose;
      
      public tabel2() {
    }

    public String getName2() {
        return name;
    }

    public void setName2(String name00) {
        this.name = name00;
    }

    public String getChoose() {
        return choose;
    }

    public void setChoose(String choose) {
        this.choose = choose;
    }



  
      
}