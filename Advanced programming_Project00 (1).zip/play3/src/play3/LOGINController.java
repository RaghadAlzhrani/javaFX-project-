/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


//
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.ResourceBundle;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.beans.binding.Binding;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
//import javax.persistence.Query;
import org.hibernate.Session;
//import org.hibernate.query.Query;

/**
 * FXML Controller class
 *
 * @author .
 */
public class LOGINController implements Initializable {

    
    
  
    @FXML
    private TextField LoginName22;
       
    @FXML
    private TextField LoginPass22;
    
  
    @FXML
    private AnchorPane SignInalert;
    @FXML
    private Label SignInmsg;
//    @FXML
//    private Label welcome;
    
    @FXML
    private Button okbutton;
    @FXML
    private Button ExitBtn;
    
    
    @FXML
    private Label mylabel1;
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        SignInalert.setTranslateX(-600);
        StringProperty textProperty=LoginName22.textProperty();
//        welcome.textProperty().bind(Bindings.concat("Welcome back, ",textProperty));
      
    }


    @FXML
    private void LoginPageBtn(ActionEvent event){
 try {
        if (LoginName22.getText().isEmpty() && LoginPass22.getText().isEmpty()) {
            trans("Please enter your information!");
            return;
        }
        if (LoginName22.getText().isEmpty() && !LoginPass22.getText().isEmpty()) {
            trans("Please enter your Name!");
            return;
        }
        if (LoginPass22.getText().isEmpty() && !LoginName22.getText().isEmpty() ) {
            trans("Please enter your password!");
            return;
        }

     
        Session session = HibernateUtil.getSessionFactory().openSession();
        String hql = "FROM tabel1 t WHERE t.userName1 = :userName1 AND t.password = :password";
        Query query = (Query) session.createQuery(hql);
        query.setParameter("userName1", LoginName22.getText());
        query.setParameter("password", LoginPass22.getText());
        List<tabel1> result = query.list();
        session.close();
        if (result.size() == 1) {
            tabel1 retrievedUser=result.get(0);
            String userName1=retrievedUser.getUserName1();
            String password=retrievedUser.getPassword();
            String massage2="Welcome : "+userName1;
            mylabel1.setText(massage2);

            trans("Login successful!");

        } else {
            // User does not exist, so show an error message
            trans("Invalid username or password!");
            
        }
    } catch (Exception e) {
        System.out.println(e.toString());
    }
    }

    @FXML
  
      private void Back(ActionEvent event) throws IOException {
    if(event.getSource() instanceof Button) {
        Button button = (Button) event.getSource();
        if(button.getId().equals("ExitBtn")) {
        Parent root = FXMLLoader.load(getClass().getResource("Login_method_selection_interface.fxml")); 
        Scene scene = new Scene(root); 
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow(); 
        stage.setScene(scene); 
        stage.show(); 
            return;
    }
    }
      }
    
    private void trans(String m){
        SignInmsg.setText(m);
        TranslateTransition slide = new TranslateTransition();
            slide.setDuration(Duration.seconds(0.4));
            slide.setNode(SignInalert);
            slide.setToX(0);
            slide.play();
    }

    @FXML
private void SignInOkBtn(ActionEvent event) throws IOException {
    // Check if the login was successful
    if (SignInmsg.getText().equals("Login successful!")) {
        // Navigate to the next page
        Parent root = FXMLLoader.load(getClass().getResource("FXML4.fxml"));  
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    } else {
        // Hide the error message
        SignInalert.setTranslateX(-500);
    }
}

}

