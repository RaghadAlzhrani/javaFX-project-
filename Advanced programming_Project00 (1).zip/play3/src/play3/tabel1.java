package play3;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import javax.persistence.Entity;
import javax.persistence.*;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 *
 * @author ط±ط؛ط¯ ط§ظ„ط²ظ‡ط±ط§ظ†ظٹ
 */

/*Columns:
userName varchar(100) PK 
userEmail varchar(120) 
password varchar(100) 
gender varchar(100)*/


@Entity
@Table(name="tabel1")
public class tabel1 implements Serializable {
    
    
     @Id
     @Column (name="userName1")
    String userName1;
     
     
     @Column (name="userEmail1")
    String userEmail1;
    
    
     
     @Column (name="password")
    String password;
     
     
     
     
     @Column (name="gender")
    String gender;

    public tabel1() {
    }

    public String getUserName1() {
        return userName1;
    }

    public String getUserEmail1() {
        return userEmail1;
    }

    public String getPassword() {
        return password;
    }

    public String getGender() {
        return gender;
    }

    public void setUserName1(String userName) {
        this.userName1 = userName;
    }

    public void setUserEmail1(String userEmail) {
        this.userEmail1 = userEmail;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
}

