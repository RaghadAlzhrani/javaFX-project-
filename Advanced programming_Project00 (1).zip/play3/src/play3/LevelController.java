/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author elafh
 */
public class LevelController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private Button level1;

    @FXML
    private Button level2;

    @FXML
    private Button level3;

    @FXML
    void level11(ActionEvent event) throws IOException {
        Parent H_Page = FXMLLoader.load(getClass().getResource("FXMLDocumentElafRehaf.fxml"));
        Scene HPage_Scene = new Scene(H_Page);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(HPage_Scene);
        stage.show();
    }

    @FXML
    void level22(ActionEvent event) throws IOException {
        Parent H_Page = FXMLLoader.load(getClass().getResource("second.fxml"));
        Scene HPage_Scene = new Scene(H_Page);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(HPage_Scene);
        stage.show();
    }

    @FXML
    void level33(ActionEvent event) throws IOException {
        Parent H_Page = FXMLLoader.load(getClass().getResource("third.fxml"));
        Scene HPage_Scene = new Scene(H_Page);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(HPage_Scene);
        stage.show();
    }
     @FXML
    private Button back1;

    @FXML
    void back2(ActionEvent event) throws IOException {
Parent H_Page = FXMLLoader.load(getClass().getResource("FXML4.fxml"));
        Scene HPage_Scene = new Scene(H_Page);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(HPage_Scene);
        stage.show();
    }
    

}
