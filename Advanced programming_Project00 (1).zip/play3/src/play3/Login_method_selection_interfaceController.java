/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Maram
 */
public class Login_method_selection_interfaceController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private Button LOGINButton;
    
       @FXML
    private Button SIGNUPButton;
       
       
       
        @FXML
    private void ChangeToTheLogin(ActionEvent event) throws IOException {
        
          Parent LoginPage = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
          Scene LoginPage2 = new Scene(LoginPage);
          Stage Window = (Stage)((Node)event.getSource()).getScene().getWindow();
          
          
          Window.setScene(LoginPage2);
          Window.show();
    }
    
    
    
      @FXML
    private void ChangeToTheSIGNU(ActionEvent event) throws IOException {
        
          Parent LoginPage = FXMLLoader.load(getClass().getResource("SIGNUP.fxml"));
          Scene LoginPage2 = new Scene(LoginPage);
          Stage Window = (Stage)((Node)event.getSource()).getScene().getWindow();
          
          
          Window.setScene(LoginPage2);
          Window.show();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        LOGINButton.setOnKeyPressed(event -> {
            try {
                goTO(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        SIGNUPButton.setOnKeyPressed(event -> {
            try {
                goTO(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    } 
        
    
//---------------------------------
    //---------------------------------
boolean rightPressed= false;
boolean enterPressed= false;
boolean leftPressed= false;
@FXML
private void goTO(KeyEvent event) throws IOException {
    if (event.getCode() == KeyCode.RIGHT) {// نتأكد انو انضغط على سهم اليمين
        rightPressed = true;
    } else if (event.getCode() == KeyCode.ENTER && rightPressed) {//  بعد مانضغط ع السهم نظغط ع انتر كمان
        Parent root = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
        Scene LogInPage = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(LogInPage);
        stage.show();
        rightPressed = false;
        enterPressed = false;
    } else {// اذا انضغط على مفتاح ثاني غير الاثنين ذولي 
        rightPressed = false;
        enterPressed = false;
    event.consume(); // نقفل الايفنت عشان مايتنفذ مره ثانيه
    }
    
////----اذا يبغى الساين اب يختار سهم اليسار وانتر ------
        if (event.getCode() == KeyCode.LEFT) {//  نتأكد انو انضضط ع سهم اليسار
        leftPressed = true;
    } else if (event.getCode() == KeyCode.ENTER && leftPressed) { //  بعد مانضغط ع السهم نظغط ع انتر كمان
        Parent root = FXMLLoader.load(getClass().getResource("SIGNUP.fxml"));
        Scene LogInPage = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(LogInPage);
        stage.show();
        leftPressed = false;
        enterPressed = false;
    } else { // اذا انضغط على مفتاح غير الاثنين ذولي 
        leftPressed = false;
        enterPressed = false;
        event.consume(); // نقفل الايفنت خلاص 
}
}
    
}

