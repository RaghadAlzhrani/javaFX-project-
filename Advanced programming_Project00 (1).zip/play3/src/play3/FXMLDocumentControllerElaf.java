/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author elafh
 */
public class FXMLDocumentControllerElaf implements Initializable {
    
    @FXML
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //plsyer.play();
    }  
     @FXML
    private Button cat;

    @FXML
    private Button camel;

    @FXML
    private Button bear;

    @FXML
    private Button next;
 
    @FXML
    private Button back;
    
    @FXML
    private Label label1;
    String answer="GOOD :) \"Correct Answer\"";
    String answer2="Sorry :( \"Try Again\"";
    
    int count=0;

 
    @FXML
    void WrongA2(ActionEvent event) {
        label1.setText(answer2);
       
    }

    private Media AudioMedia = new Media("https://d.top4top.io/m_2705drj5b1.mp3");
    MediaPlayer catsound2=new MediaPlayer(AudioMedia);
   
 @FXML
    public void catsound(MouseEvent event) {
        catsound2.play();
  //  plsyer.play();
    }
   private Media clapAudio = new Media("https://l.top4top.io/m_27058266t1.mp3");
    MediaPlayer clap=new MediaPlayer(clapAudio);
    @FXML
    void correctA(ActionEvent event) {
    label1.setText(answer);
    clap.play();
    count++;
    }

    @FXML
    void wrongA(ActionEvent event) {
    label1.setText(answer2);
    }

 @FXML
    void nextpage(ActionEvent event) throws IOException {
        
    Parent H_Page=FXMLLoader.load(getClass().getResource("second.fxml"));
    Scene HPage_Scene = new Scene(H_Page);
    Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
    stage.setScene(HPage_Scene);
    stage.show();
    }  
     @FXML
    void backhome2(MouseEvent event) throws IOException {
Parent H_Page=FXMLLoader.load(getClass().getResource("level.fxml"));
    Scene HPage_Scene = new Scene(H_Page);
    Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
    stage.setScene(HPage_Scene);
    stage.show();
    }
   
     
   

    
}
//Parent H_Page=FXMLLoader.load(getClass().getResource("/second.fxml"));
//    Scene HPage_Scene = new Scene(H_Page);
//    Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
//    stage.setScene(HPage_Scene);
//    stage.show();