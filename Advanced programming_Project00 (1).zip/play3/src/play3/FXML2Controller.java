/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package play3;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author extra
 */
public class FXML2Controller implements Initializable {

    
  
    @FXML
   private TextField v;
   private Label lb;
   private Button b;
   private ImageView Imag2;
      
   private Media AudioHint2 = new Media("https://b.top4top.io/m_27050x21p1.mp3");
    MediaPlayer Hint2=new MediaPlayer(AudioHint2); 

   
    public void Hint(ActionEvent event) {
        Hint2.play();
    }         
        
        
    private Media AudioNoo2 = new Media("https://e.top4top.io/m_27051a7781.mp3");
    MediaPlayer Noo2=new MediaPlayer(AudioNoo2);      
        
        
    private Media AudioWow2 = new Media("https://c.top4top.io/m_2705j34ng1.mp3");
    MediaPlayer Wow2=new MediaPlayer(AudioWow2);

    public void OK(ActionEvent event) throws IOException {
        Wow2.play();
       if (v.getText().equalsIgnoreCase("Appel")) {
        
        
            Parent root = FXMLLoader.load(getClass().getResource("level3.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
       else {        
           Noo2.play();
       }

    }
     public void load(MouseEvent event) throws IOException {
     
         Parent root = FXMLLoader.load(getClass().getResource("level3.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    

         
    }
      public void loadhome(MouseEvent event) throws IOException {
     
         
         Parent root = FXMLLoader.load(getClass().getResource("FXML4.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         RotateTransition y=new RotateTransition();
         y.setNode(Imag2);
        y.setDuration(javafx.util.Duration.millis(1000));
         y.setCycleCount(TranslateTransition.INDEFINITE);
         y.setInterpolator(Interpolator.LINEAR);
         y.setByAngle(360);
         y.play();
    }  
    }    
    


    
    

