/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package play3;

import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.ResourceBundle;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import static javafx.scene.input.KeyCode.L;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author extra
 */
public class FXML4Controller implements Initializable {

    /**
     * Initializes the controller class.
     */
     @FXML
 private ImageView imag;
     @FXML
 private ImageView imag2;
     @FXML
 private ImageView image2;
     @FXML
 private ImageView imag4;
  @FXML
 private ImageView Sound;
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       
             
        TranslateTransition x= new TranslateTransition();
        x.setNode(imag);
        
        x.setDuration(javafx.util.Duration.millis(8000));
        x.setCycleCount(TranslateTransition.INDEFINITE);
        x.setByY(-700);
       x.play();
       TranslateTransition y= new TranslateTransition();
        y.setNode(image2);
        
        y.setDuration(javafx.util.Duration.millis(8000));
        y.setCycleCount(TranslateTransition.INDEFINITE);
        y.setByY(-700);
        y.play();
       
    }
    
       public void Sound(MouseEvent event) throws IOException {
        
       }
            
 
    /**
     * Initializes the controller class.
     */
     public void load(MouseEvent event) throws IOException {
     
         
         Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
          public void load2(MouseEvent event) throws IOException {
     
       Parent root = FXMLLoader.load(getClass().getResource("level.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }  
          
      public void load3(MouseEvent event) throws IOException {
     
         
         Parent root = FXMLLoader.load(getClass().getResource("level.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
         public void load4(MouseEvent event) throws IOException {
     
         
         Parent root = FXMLLoader.load(getClass().getResource("Q1.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    }
         public void HOME(MouseEvent event) throws IOException {
     
         
         Parent root = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
       Scene scene = new Scene(root);
     Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
     stage.setScene(scene);
     stage.show();
    } 
    }    
    

