
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;


import javafx.scene.shape.Rectangle;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.TranslateTransition;
import javafx.beans.binding.Bindings;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


/**
 * FXML Controller class
 *
 * @author SIGN
 */
public class SIGNUPController implements Initializable{
 
    @FXML
    private TextField TextFild_SignUpEmail;
    @FXML
    private TextField TextFild_SignUpName1; 
    //********************************//
    @FXML
    private ImageView imgg_Background;
    @FXML
    private Rectangle Rectangle2UP;
    @FXML
    private PasswordField TextFild_SignUpPass; 
    //********************************//
    @FXML
    private RadioButton RadioButtonFM, RadioButtonMal; 
    @FXML
    private Button SignUpBtn, BackBtn, OkkBtn;

    //********************************//
    //********************************//
    @FXML
    private AnchorPane SignUpalert ,anch_Background;  //
    @FXML
    private Label SignUpMsg, Label_SignUpGen, Label_SignUpPass, Label_SignUpEmail,label00, Label_SignUpName, Label_SignUpFinger ;//
    private Object txtusername;

    /**
     * Initializes the controller class.
     */
        @Override
    public void initialize(URL url, ResourceBundle rb) {
         
        SignUpalert.setTranslateX(-500); 
        StringProperty textProperty =TextFild_SignUpName1.textProperty();
        label00.textProperty().bind(Bindings.concat("WELCOME ",textProperty));
    }

    @FXML
    private void SignUpPageBtn(ActionEvent event) throws IOException {



      
        try {

            if (TextFild_SignUpName1.getText().isEmpty()&& TextFild_SignUpEmail.getText().isEmpty() && TextFild_SignUpPass.getText().isEmpty()){
//                 Audio.sound1();
                trans("Please Enter your Information!");
                return;
            }
            if (TextFild_SignUpName1.getText().isEmpty()){
//                Audio.sound1();
                trans("Please Enter your Name!");
                return;
            }
            if (TextFild_SignUpEmail.getText().isEmpty()) {
//                Audio.sound1();
                trans("Please Enter your Email!");
                return;
            }
            if (!(TextFild_SignUpEmail.getText().isEmpty())&&!(TextFild_SignUpEmail.getText().contains("@"))){
//                Audio.sound1();
                TextFild_SignUpEmail.clear();
                trans("Invalid Email!");
                return;
            }
            if (TextFild_SignUpPass.getText().isEmpty()){
//                Audio.sound1();
                trans("Please Enter a password!");
                return;
                }
            tabel1 u = new tabel1();
            if(RadioButtonMal.isSelected())
            u.setGender("Male");
            else if(RadioButtonFM.isSelected())
                            u.setGender("Female");

            u.setUserEmail1(TextFild_SignUpEmail.getText());
            u.setUserName1(TextFild_SignUpName1.getText());
            u.setPassword(TextFild_SignUpPass.getText());
            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            session.save(u);
            tx.commit();
            session.close(); 

            
            Parent root = FXMLLoader.load(getClass().getResource("FXML4 .fxml"));
            Scene scen = new Scene(root);
           Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scen);
            stage.show();   
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    @FXML
    private void Back(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login_method_selection_interface.fxml"));
        Scene MySignInPage = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(MySignInPage);
        stage.show();
    }

    private void trans(String m){
        SignUpMsg.setText(m);
        TranslateTransition slide = new TranslateTransition();
            slide.setDuration(Duration.seconds(0.4));
            slide.setNode(SignUpalert);
            slide.setToX(0);
            slide.play();
    }

    @FXML
    private void okBtn(ActionEvent event) {
        SignUpalert.setTranslateX(-500);
    }
}
