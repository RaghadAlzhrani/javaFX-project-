/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package play3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import javax.persistence.Query;


/**
 * FXML Controller class
 *
 * @author elafh
 */
public class EvaluationPageController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private TextField name;

    @FXML
    private RadioButton good;

    @FXML
    private RadioButton bad;

    @FXML
    private RadioButton ex;

    @FXML
    private Button nextt;

    @FXML
    private Button backk;
    @FXML
    private Button send;
    
    @FXML
    private TextArea textarea1;

    @FXML
    private Label labelif;

    @FXML
    private Button submit2;

    @FXML
    void back(ActionEvent event) throws IOException {
 Parent H_Page=FXMLLoader.load(getClass().getResource("FXML4.fxml"));
    Scene HPage_Scene = new Scene(H_Page);
    Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
    stage.setScene(HPage_Scene);
    stage.show();
    }

    @FXML
    void name1(ActionEvent event) {}
      @FXML
   private void send1(ActionEvent event) throws IOException{
        try{
        tabel2 e = new tabel2();
            if(ex.isSelected())
            e.setChoose("excellent");
            else {if(good.isSelected())
                            e.setChoose("good");
            else if(bad.isSelected())
                e.setChoose("bad");
                }
            e.setName2(name.getText());
            Session session = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session.beginTransaction();
            session.save(e);
            tx.commit();
            session.close();
        }
catch (Exception e) {
            System.out.println(e.toString());}}
    

    @FXML
    void next(ActionEvent event) throws IOException {
 Parent H_Page=FXMLLoader.load(getClass().getResource("FXML4.fxml"));
    Scene HPage_Scene = new Scene(H_Page);
    Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
    stage.setScene(HPage_Scene);
    stage.show();
    }
    
    @FXML
     private  void openFile(ActionEvent event) throws FileNotFoundException {
        File f = new File("ex.txt");
        //System.out.println("File path: " + f.getAbsolutePath());
        Scanner Scan = new Scanner(f);
        String s= "";
        while (Scan.hasNextLine()){
        s+=Scan.nextLine()+"\n";
        }
            textarea1.setText(s);
           
        
    }
}