/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */ 
package play3;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
/**
 * FXML Controller class
 *
 * @author elafh
 */
public class ThirdController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
     @FXML
    private Button girafe;

    @FXML
    private Button cow;

    @FXML
    private Button lion;

    @FXML
    private Label lable3;

    @FXML
    private Button sound;

    String answer="GOOD :) \"Correct Answer\"";
    String answer2="Sorry :( \"Try Again\"";
    
    int count=0;
    private Media clapAudio3 = new Media("https://l.top4top.io/m_27058266t1.mp3");
    MediaPlayer clap3=new MediaPlayer(clapAudio3);
    @FXML
    void correctA(ActionEvent event) {
    lable3.setText(answer);
    clap3.play();
    count++;
   
    }
    
    
    
   private Media AudioMedial = new Media("https://l.top4top.io/m_27053zz491.mp3");
    MediaPlayer lionsound2=new MediaPlayer(AudioMedial);
    
   
 @FXML
    public void lionsound(MouseEvent event) {
//    plsyer.play(); 
lionsound2.play();
    }
    @FXML
    
    
    void wrongA(ActionEvent event) {
    lable3.setText(answer2);
    }

    @FXML
    void wrongA2(ActionEvent event) {
    lable3.setText(answer2);
    }

     @FXML
    private Button back;

    @FXML
    void bakeHome(MouseEvent event) throws IOException {
    Parent H_Page=FXMLLoader.load(getClass().getResource("level.fxml"));
    Scene HPage_Scene = new Scene(H_Page);
    Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
    stage.setScene(HPage_Scene);
    stage.show();
    }

    
}
